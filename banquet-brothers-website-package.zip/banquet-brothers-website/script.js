const menuToggle = document.querySelector('.menu-toggle');
const siteNav = document.querySelector('.site-nav');
const form = document.querySelector('#catering-form');

document.querySelector('#year').textContent = new Date().getFullYear();

menuToggle?.addEventListener('click', () => {
  const isOpen = siteNav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(isOpen));
});

siteNav?.querySelectorAll('a').forEach((link) => {
  link.addEventListener('click', () => {
    siteNav.classList.remove('open');
    menuToggle?.setAttribute('aria-expanded', 'false');
  });
});

form?.addEventListener('submit', (event) => {
  event.preventDefault();

  const data = new FormData(form);
  const name = String(data.get('name') || '');
  const phone = String(data.get('phone') || '');
  const email = String(data.get('email') || '');
  const date = String(data.get('date') || 'Not provided');
  const guests = String(data.get('guests') || 'Not provided');
  const eventType = String(data.get('eventType') || 'Other');
  const details = String(data.get('details') || 'No additional details provided.');

  const subject = `Catering Request from ${name}`;
  const body = [
    'Hello Banquet Brothers,',
    '',
    'I would like to request catering information.',
    '',
    `Name: ${name}`,
    `Phone: ${phone}`,
    `Email: ${email}`,
    `Event Date: ${date}`,
    `Guest Count: ${guests}`,
    `Event Type: ${eventType}`,
    '',
    'Menu Ideas / Special Requests:',
    details,
    '',
    'Thank you!'
  ].join('\n');

  window.location.href = `mailto:TheBanquetBrothers@yahoo.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
});
