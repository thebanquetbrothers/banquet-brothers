BANQUET BROTHERS WEBSITE - FREE SETUP INSTRUCTIONS
==================================================

WHAT IS INCLUDED
----------------
- index.html ........ Main website page
- styles.css ........ Green-and-black website design
- script.js ......... Mobile menu and catering request form
- assets/ ........... Logo and food artwork

HOW TO PREVIEW THE WEBSITE
--------------------------
1. Unzip the downloaded folder.
2. Open the folder named "banquet-brothers-website".
3. Double-click "index.html".
4. The website will open in your browser.

100% FREE PUBLISHING OPTION: GITHUB PAGES
-----------------------------------------
1. Create a free account at github.com.
2. Click the plus (+) button and choose "New repository".
3. Name it: banquet-brothers-website
4. Select "Public" and click "Create repository".
5. Click "uploading an existing file".
6. Upload ALL files and the assets folder from this package.
7. Click "Commit changes".
8. Open the repository's "Settings" tab.
9. In the left menu, click "Pages".
10. Under "Build and deployment," choose:
    - Source: Deploy from a branch
    - Branch: main
    - Folder: / (root)
11. Click "Save".
12. GitHub will display your free website address after publishing.

EASIER FREE PUBLISHING OPTION: NETLIFY DROP
-------------------------------------------
1. Unzip this website package.
2. Visit app.netlify.com/drop in a browser.
3. Drag the complete "banquet-brothers-website" folder onto the page.
4. Netlify will publish the website and provide a free website address.
5. Create a free Netlify account if you want to keep and rename the site.

HOW THE CATERING FORM WORKS
---------------------------
The website is completely static and free. It does not collect or store customer information.
When a customer completes the form and clicks "Create Email Request," their email app opens with the request already filled in and addressed to:
TheBanquetBrothers@yahoo.com

HOW TO EDIT THE MENU OR WORDING
-------------------------------
1. Right-click index.html.
2. Open it with Notepad, TextEdit, or another text editor.
3. Find the wording you want to change.
4. Make the change and save.
5. Upload the updated file to your website host.

CONTACT INFORMATION CURRENTLY USED
----------------------------------
Phone: 1-888-812-2673
Email: TheBanquetBrothers@yahoo.com
Facebook: The Banquet Brothers
Instagram: @thebanquetbrother

IMPORTANT NOTE ABOUT THE LOGO
-----------------------------
This package includes a newly created text-based Banquet Brothers logo so the website is complete and ready to open.
You can replace assets/logo.svg with your official Banquet Brothers logo later. Keep the new file name as logo.svg, or update the image file name inside index.html.
